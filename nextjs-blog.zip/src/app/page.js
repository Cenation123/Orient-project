import React, { Suspense } from "react";

import "./home.css";
import Head from "next/head";
import HomePage from "./_homePage/page";

export default function Home() {
  return (
    <>
      <Head>
        <title>My Next.js Website</title>
        <meta name="description" content="This is my Next.js website" />
        <meta name="keywords" content="nextjs, website, tutorial" />
      </Head>
      <Suspense fallback={<div>Loading...</div>}>
        <HomePage />
      </Suspense>
    </>
  );
}
