import React from 'react'

export default function investment() {
  return (
    <div>
      <h1>this is investment</h1>
    </div>
  )
}
