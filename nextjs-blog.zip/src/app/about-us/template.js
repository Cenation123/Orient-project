import React from 'react'

export default function template({children}) {
  return (
    <div>
      <h1>this is temp</h1>
      {children}
    </div>
  )
}
  