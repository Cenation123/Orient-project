import React from 'react'

export default function Profile() {
  return (
    <div><h1>this is profile</h1></div>
  )
}
